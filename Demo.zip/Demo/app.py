import psycopg2
from flask import Flask, render_template, request

app = Flask(__name__)
app.url_map.strict_slashes = False


@app.route('/')
def Index():
    return render_template('index.html')


@app.route('/index')
def Home():
    return render_template('index.html')


@app.route('/about-overview')
def AboutOverView():
    return render_template('about-overview.html')


@app.route('/who-we-are')
def WhoWEAre():
    return render_template('who-we-are.html')


@app.route('/business-modal')
def BusinessModal():
    return render_template('business-modal.html')


@app.route('/core-values')
def CoreValues():
    return render_template('core-values.html')


@app.route('/our-strengths')
def OurStrengths():
    return render_template('our-strengths.html')


@app.route('/our-mission')
def OurMission():
    return render_template('our-mission.html')


@app.route('/services-overview')
def ServicesOverview():
    return render_template('services-overview.html')


@app.route('/it-service')
def ITService():
    return render_template('it-service.html')


@app.route('/application-development')
def ApplicationDevelopment():
    return render_template('application-development.html')


@app.route('/software-quality')
def SoftwareQuality():
    return render_template('software-quality.html')


@app.route('/it-consulting')
def ITConsulting():
    return render_template('it-consulting.html')


@app.route('/offshore-service')
def OffshoreService():
    return render_template('offshore-service.html')


@app.route('/it-staffing')
def ItStaffing():
    return render_template('it-staffing.html')


@app.route('/events')
def Events():
    return render_template('events.html')


@app.route('/career')
def Career():
    return render_template('career.html')


@app.route('/quality')
def Quality():
    return render_template('quality.html')


@app.route('/contact', methods=['GET', 'POST'])
def Contact():
    return render_template('contact.html')


@app.route('/upload', methods=['POST'])
def GetInTouch():
    pname = request.form.get('name')
    pemail = request.form.get('email')
    pcompany = request.form.get('company')
    pcontact = request.form.get('contact')
    pmessage = request.form.get('message')
    print pname
    print pemail
    print pcompany
    print pcontact
    print pmessage

    conn = psycopg2.connect(database="rajesh", user="postgres", password="manager", host="127.0.0.1", port="5432")
    cur = conn.cursor()
    cur.execute("INSERT INTO contact (NAME,EMAIL,COMPANY,CONTACT,MESSAGE) \
          VALUES ('"+request.form.get('name')+"','"+request.form.get('email')+"','"+request.form.get('company')+"','"+request.form.get('contact')+"','"+request.form.get('message')+"' )")

    return render_template('index.html')


if __name__ == '__main__':
    app.debug = True
    app.run()
