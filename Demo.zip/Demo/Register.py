class Register:
    def __init__(self, name, email, company, contact, message):
        self.name = name
        self.email = email
        self.company = company
        self.contact = contact
        self.message = message
